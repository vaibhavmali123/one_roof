class WorkerSelector<T>{
  bool isSelected=false;


  WorkerSelector(this.data);

  T data;
}