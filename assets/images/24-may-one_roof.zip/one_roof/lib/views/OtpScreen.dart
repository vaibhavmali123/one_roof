import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:one_roof/blocs/DeviceTypeBloc.dart';
import 'package:one_roof/main.dart';
import 'package:one_roof/utils/AppStrings.dart';
import 'package:one_roof/utils/Constants.dart';
import 'package:one_roof/utils/color.dart';
import 'package:one_roof/views/MoreAbout.dart';
import 'package:one_roof/views/TellMoreAboutsecond.dart';
import 'package:pin_code_text_field/pin_code_text_field.dart';

class OtpScreen extends StatefulWidget{

  final String accountType;

  OtpScreen(this.accountType);

  OtpScreenState createState()=>OtpScreenState(accountType);
}

class OtpScreenState extends State<OtpScreen>
{
  final String accountType;

  OtpScreenState(this.accountType);
  FirebaseMessaging _firebaseMessaging;

  TextEditingController controller = TextEditingController(text: "");
  DeviceTypeBloc deviceTypeBloc;
  @override
  void initState() {
    _firebaseMessaging=FirebaseMessaging();
    super.initState();
    deviceTypeBloc=DeviceTypeBloc();
    initNotification();
  }
  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      appBar:PreferredSize(
          preferredSize:Size.fromHeight(80),
          child:
          Column(
            children: [
              SizedBox(height:20,),
              AppBar(
                  backgroundColor:Colors.transparent,
                  elevation:0,
                  centerTitle:true,
                  title:Text("Verify mobile no.",style:TextStyle(fontSize:14,
                      color:Colors.black,fontWeight:FontWeight.w900)),
                  leading:GestureDetector(
                    child:Image.asset('assets/images/back_icon.png',scale:1.8,),
                    onTap:(){
                      Get.back();
                    },
                  )
              )
            ],
          )
      ),

      body:
      SafeArea(
        child:
        Column(
          mainAxisSize:MainAxisSize.max,
          mainAxisAlignment:MainAxisAlignment.spaceEvenly,
          children: [
            Expanded(child:Container(
              child:Column(
                children: [
                  Expanded(
                    flex:2,
                    child:Column(
                      children: [
                        SizedBox(height:24,),
                        Text('OTP is sent to +91 96562 49959',style:
                        GoogleFonts.openSans(textStyle:TextStyle(fontSize:15,color:Colors.black38,
                            fontWeight:FontWeight.w700,letterSpacing:0.0))),
                        Text('Re-enter mobile no.',style:
                        GoogleFonts.openSans(textStyle:TextStyle(fontSize:14,
                            color:color.colorConvert('#0457BE'),
                            fontWeight:FontWeight.w700,letterSpacing:0.0)))
                      ],
                    ),),
                  Expanded(
                      flex:4,
                      child:Column(
                        children: [
                          Text("Enter 4 digit OTP",style:TextStyle(fontSize:18,
                              color:Colors.black,fontWeight:FontWeight.w700)),
                          SizedBox(height:18,),
                          PinCodeTextField(
                            autofocus:false,
                            hideCharacter: false,
                            highlight: true,
                            pinBoxOuterPadding:EdgeInsets.symmetric(horizontal:14),
                            highlightColor: Colors.black,
                            defaultBorderColor: Colors.black38,
                            hasTextBorderColor: Colors.black38,
                            highlightPinBoxColor: Colors.white,
                            maxLength: 4,
                            // maskCharacter: "*",
                            onTextChanged:(text){
                              print("DONE CONTROLLER ${controller.text}");
                            },
                            pinBoxWidth: 50,
                            pinBoxHeight: 55,
                            hasUnderline: false,
                            wrapAlignment: WrapAlignment.spaceAround,
                            pinBoxDecoration:
                            ProvidedPinBoxDecoration.defaultPinBoxDecoration,
                            pinTextStyle: TextStyle(fontSize: 22.0),
                            pinTextAnimatedSwitcherTransition:
                            ProvidedPinBoxTextAnimation.scalingTransition,
                            pinBoxColor: Colors.white,
                            pinTextAnimatedSwitcherDuration:
                            Duration(milliseconds: 300),
                            pinBoxRadius:10.0,
//                    highlightAnimation: true,
                            highlightAnimationBeginColor: Colors.black,
                            highlightAnimationEndColor: Colors.white12,
                            keyboardType: TextInputType.number,
                          ),
                          SizedBox(height:18,),
                          Text.rich(
                            TextSpan(
                                text:AppStrings.didntReceiveOtp,style:
                            GoogleFonts.openSans(textStyle:TextStyle(fontSize:14,color:color.colorConvert('#6B6977'),
                                fontWeight:FontWeight.w600,letterSpacing:0.0)),
                                children:<InlineSpan>[
                                  TextSpan(
                                    text:" "+AppStrings.requestAgain,style:
                                  GoogleFonts.openSans(textStyle:TextStyle(fontSize:12,
                                      color:color.colorConvert('#0457BE'),
                                      letterSpacing:0.0)),
                                  )
                                ]
                            ),)
                        ],
                      )
                  )
                ],
              ),

            )),
            Align(
                alignment:Alignment.bottomCenter,
                child:Padding(
                  padding:EdgeInsets.only(bottom:20),
                  child:ButtonTheme(
                    minWidth:MediaQuery.of(context).size.width/2.4,
                    height:52,
                    child:RaisedButton(
                        child:Text(AppStrings.verify,style:TextStyle(fontSize:16,
                            color:Colors.white),),
                        color:color.colorConvert(color.primaryColor),
                        shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12.0)),
                        onPressed:(){
                          print("ACC ${accountType}");

                          accountType=="hire"?Get.to(MoreAbout(accountType)):
                          Get.to(TellMoreAboutsecond(accountType));
                        }),),
                )
            )
          ],
        ),
      ),
    );
  }

  void initNotification() async{

    _firebaseMessaging.configure(
        onMessage:(Map<String,dynamic>map)async{
          print("Notification ${map['notification']}");
          Map<String,dynamic>mapData;
          setState(() {
            mapData={"title":map['notification']['title'],
              "body":map['notification']['body']};
          });
          print("Notification ${map['notification'].toString()}");
          print("Notification ${map['notification']['title']}");
          print("Notification ${map['notification']['body']}");

          print("Notification ${mapData.toString()}");

          _showNotification(mapData);

        },
        onLaunch:(Map<String,dynamic>map)async{
          print("Notification l${map.toString()}");
          _showNotification(map);

        },
        //onBackgroundMessage:myBackgroundHandler,
        onResume:(Map<String,dynamic>map)async{
          print("Notification r ${map.toString()}");
        }
    );
  }

  Future _showNotification(Map<String, dynamic> mesage) async {
    var androidPlatformChannelSpecifics = AndroidNotificationDetails(
        'channel_ID', 'channel_name', 'channel description',
        importance: Importance.high,
        playSound: true,
        // sound: 'sound',
        showProgress: true,
        priority: Priority.high,
        ticker: 'test ticker');

    var platformChannelSpecifics =
    NotificationDetails(android: androidPlatformChannelSpecifics);
    print("Channel :${platformChannelSpecifics.android.channelId}");
    await flutterLocalNotificationsPlugin.show(0, mesage['title'],
        mesage['body'], platformChannelSpecifics,
        payload: 'Default_Sound');
  }
}