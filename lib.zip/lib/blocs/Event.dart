enum NotificationsEvent{
  fetchNotifications
}