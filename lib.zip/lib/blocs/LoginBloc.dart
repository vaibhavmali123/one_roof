class LoginBloc
{

}