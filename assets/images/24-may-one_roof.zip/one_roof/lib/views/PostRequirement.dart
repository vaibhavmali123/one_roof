import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_uploader/flutter_uploader.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:one_roof/models/CitiesModel.dart';
import 'package:path/path.dart' as path;
import 'package:hive/hive.dart';
import 'package:image_picker/image_picker.dart';
import 'package:one_roof/networking/ApiHandler.dart';
import 'package:one_roof/networking/ApiKeys.dart';
import 'package:one_roof/networking/ApiProvider.dart';
import 'package:one_roof/networking/EndApi.dart';
import 'package:one_roof/utils/AppStrings.dart';
import 'package:one_roof/utils/ToastMessages.dart';
import 'package:one_roof/utils/color.dart';
import 'package:one_roof/views/OrderPage.dart';
import 'package:http/http.dart' as http;
import 'package:async/async.dart';
import 'dart:convert';
class PostRequirement extends StatefulWidget
{
  String selectedValue;
String colorCode,categoryName;

  PostRequirement(this.selectedValue,this.colorCode,this.categoryName);

  PostRequirementState createState()=>PostRequirementState(selectedValue,colorCode,categoryName);
}

class PostRequirementState extends State<PostRequirement>
{
  String selectedValue,categoryName;
  var selectedCity;
   List<CitiesList> _cityDropdownValues = [];
  TextEditingController projectNameCtrl,briefCtrl;
  String colorCode,srNo;
  bool showLoader=false;
  PostRequirementState(this.selectedValue,this.colorCode,this.categoryName);
  FirebaseMessaging _firebaseMessaging;
  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
  new FlutterLocalNotificationsPlugin();
String fcmToken;
  final picker=ImagePicker();
  File image,croppedImage;
  String fileStr;
  static String uploadedFileUrl;
  final List<String> _localityDropdownValues = [
    "Katraj",
    "Baner",
    "Swargate",
  ];

String selectedCityId,selectedLoc;
  @override
  void initState() {
    _firebaseMessaging=FirebaseMessaging();
    initNotification();
    getToken();
    super.initState();
    projectNameCtrl=TextEditingController();
    briefCtrl=TextEditingController();

    getLocations();
  }

  @override
  Widget build(BuildContext context)
  {
    double dimens=MediaQuery.of(context).size.height;

    return Scaffold(
      //resizeToAvoidBottomPadding:false,
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(75),
          child: Column(
            children: [
              SizedBox(
                height: 15,
              ),
              AppBar(
                backgroundColor: Colors.white,
                elevation:2,
                centerTitle: true,
                automaticallyImplyLeading:false,
                actions: [
                  Container(
                    width:Get.size.width,
                    child:Row(
                      mainAxisAlignment:MainAxisAlignment.start,
                      children: [
                        Expanded(
                            flex:1,
                            child:GestureDetector(
                              onTap:(){
                                Get.back();
                              },
                              child: Image.asset(
                                'assets/images/back_icon.png',
                                scale: 1.8,
                              ),
                            )),
                        Expanded(
                          flex:5,
                          child:Text(selectedValue,
                              style: TextStyle(
                                  fontSize: 17,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w700)),),
                        Expanded(
                          flex:1,
                          child:Container(),
                        )
                      ],
                    ),
                  )
                ],
              )
            ],
          )),

   body:
   showLoader==false?SingleChildScrollView(
       child:
       showLoader==false?IntrinsicHeight(
         // height:Get.size.height/1.4,
           //height:dimens<=725?Get.size.height/1.2:Get.size.height/1.4,
           child:Column(
             children: [
               SizedBox(height:15,),
               Expanded(
                 flex:dimens>=725?2:1,
                 child:Row(
                   mainAxisAlignment:MainAxisAlignment.center,
                   children: [
                     Text(AppStrings.postRequirement,
                         maxLines:2,
                         overflow: TextOverflow.ellipsis,
                         softWrap: false,
                         style: GoogleFonts.openSans(
                             textStyle: TextStyle(
                                 fontSize:15,
                                 color:color.colorConvert('#343048').withOpacity(0.8),
                                 fontWeight: FontWeight.w600,
                                 letterSpacing: 0.0))),
                   ],
                 ),
               ),
               SizedBox(height:50,),
               Expanded(
                   flex:16,
                   child:Row(
                     mainAxisAlignment:MainAxisAlignment.center,
                     children: [
                       Column(
                         children: [
                           SizedBox(
                             height:65,
                             width:Get.size.width/1.1,
                             child:TextField(
                               controller:projectNameCtrl,
                               keyboardType:TextInputType.text,
                               showCursor:true,
                               cursorWidth:2,
                               autofocus:false,
                               style: TextStyle(color:Colors.black87,fontWeight: FontWeight.w500),
                               decoration:InputDecoration(
                                 isDense:true,
                                 hintStyle:TextStyle(fontSize:14,
                                     color:Colors.black54,fontWeight:FontWeight.w500),

                                 hintText:"Project Name",
                                 errorStyle: TextStyle(height: 0),
                                 enabledBorder:OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8.0)),
                                     borderSide:BorderSide(color:Colors.black38)),
                                 focusedBorder:OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8.0)),borderSide:
                                 BorderSide(color:Colors.black38)),
                               ),
                               //cursorColor:color.colorConvert(color.PRIMARY_COLOR),
                             ),
                           ),
                           SizedBox(height:15,),
                           Container(
                             height: 54,
                             width: Get.size.width / 1.1,
                             decoration: BoxDecoration(
                                 borderRadius: BorderRadius.circular(8.0),
                                 border: Border.all(width: 1, color: Colors.black38)),
                             child: Center(
                               child: Theme(
                                 data: Theme.of(context).copyWith(
                                     canvasColor: Colors.white,
                                     // background color for the dropdown items
                                     buttonTheme: ButtonTheme.of(context).copyWith(
                                       alignedDropdown:
                                       true, //If false (the default), then the dropdown's menu will be wider than its button.
                                     )),
                                 child: DropdownButton<String>(
                                   underline: Container(
                                     height: 1.0,
                                     decoration: const BoxDecoration(
                                         border: Border(
                                             bottom:
                                             BorderSide(color: Colors.transparent, width: 0.0))),
                                   ),
                                   isExpanded: true,
                                   focusColor: Colors.white,
                                   value:selectedCity,
                                   style: TextStyle(color: Colors.white),
                                   iconEnabledColor: Colors.black,
                                   icon: Image.asset(
                                     'assets/images/dropDown_icon.png',
                                     height: 22,
                                     width: 22,
                                   ),
                                   items: _cityDropdownValues
                                       .map<DropdownMenuItem<String>>((CitiesList value) {
                                     return DropdownMenuItem<String>(
                                       value:value.cityName,
                                       child: Text(
                                         value.cityName,
                                         style: TextStyle(
                                             color: Colors.black87, fontWeight: FontWeight.w500),
                                       ),
                                     );
                                   }).toList(),
                                   hint: Text(
                                     "Select Your city",
                                     style: TextStyle(
                                         fontSize: 14,
                                         color: selectedCity != null ? Colors.black87 : Colors.black54,
                                         fontWeight: FontWeight.w500),
                                   ),
                                   onChanged: (String value) {
                                     setState(() {
                                       FocusScope.of(context).requestFocus(new FocusNode());
                                       selectedCity = value;
                                       for(int i=0;i<_cityDropdownValues.length;i++)
                                         {
                                           if (_cityDropdownValues[i].cityName==value) {
                                             setState(() {
                                               selectedCityId=_cityDropdownValues[i].id;
                                             });
                                           }
                                         }
                                       getLocality();
                                     });
                                   },
                                 ),
                               ),
                             ),
                           ),
                          SizedBox(height:18,),
                           Container(
                             height: 54,
                             width: Get.size.width / 1.1,
                             decoration: BoxDecoration(
                                 borderRadius: BorderRadius.circular(8.0),
                                 border: Border.all(width: 1, color: Colors.black38)),
                             child: Center(
                               child:
                               Theme(
                                 data: Theme.of(context).copyWith(
                                     canvasColor: Colors.white,
                                     buttonTheme: ButtonTheme.of(context).copyWith(
                                       alignedDropdown:
                                       true, //If false (the default), then the dropdown's menu will be wider than its button.
                                     )),
                                 child: DropdownButton<String>(
                                   underline: Container(
                                     height: 1.0,
                                     decoration: const BoxDecoration(
                                         border: Border(
                                             bottom:
                                             BorderSide(color: Colors.transparent, width: 0.0))),
                                   ),
                                   isExpanded: true,
                                   focusColor: Colors.white,
                                   value: selectedLoc,
                                   style: TextStyle(color: Colors.white),
                                   iconEnabledColor: Colors.black,
                                   icon: Image.asset(
                                     'assets/images/dropDown_icon.png',
                                     height: 22,
                                     width: 22,
                                   ),
                                   items: _localityDropdownValues
                                       .map<DropdownMenuItem<String>>((String value) {
                                     return DropdownMenuItem<String>(
                                       value: value,
                                       child: Text(
                                         value,
                                         style: TextStyle(
                                             color: Colors.black87, fontWeight: FontWeight.w500),
                                       ),
                                     );
                                   }).toList(),
                                   hint: Text(
                                     AppStrings.locality,
                                     style: TextStyle(
                                         fontSize: 14,
                                         color: selectedLoc != null ? Colors.black : Colors.black54,
                                         fontWeight: FontWeight.w500),
                                   ),
                                   onChanged: (String value) {
                                     setState(() {
                                       FocusScope.of(context).requestFocus(new FocusNode());
                                       selectedLoc = value;
                                     });
                                   },
                                 ),
                               ),
                             ),
                           ),
                           SizedBox(height:5,),
                           Container(
                             margin:EdgeInsets.only(top:2),
                             width:Get.size.width/1.1,
                             child:Row(
                               mainAxisAlignment:MainAxisAlignment.end,
                               children: [
                                 Expanded(
                                     flex:3,
                                     child:Container()),
                                 Expanded(
                                   flex:4,
                                   child:Text(AppStrings.selectNearby,
                                       maxLines:2,
                                       overflow: TextOverflow.ellipsis,
                                       softWrap: false,
                                       style: GoogleFonts.openSans(
                                           textStyle: TextStyle(
                                               fontSize:10,
                                               color:Colors.black45,
                                               fontWeight: FontWeight.w700,
                                               letterSpacing: 0.0))),
                                 )
                               ],
                             ),
                           ),
                           SizedBox(height:20,),
                           Container(
                             width:Get.size.width/1.1,
                             child:TextField(
                               controller:briefCtrl,
                               keyboardType:TextInputType.text,
                               showCursor:true,
                               cursorWidth:2,
                               maxLines:4,
                               autofocus:false,
                               style: TextStyle(color:Colors.black87,fontWeight: FontWeight.w500),
                               decoration:InputDecoration(
                                 isDense:true,
                                 hintStyle:TextStyle(fontSize:14,
                                     color:Colors.black54,fontWeight:FontWeight.w500),
                                 hintText:"Brief Description",
                                 errorStyle: TextStyle(height: 0),
                                 enabledBorder:OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8.0)),
                                     borderSide:BorderSide(color:Colors.black38)),
                                 focusedBorder:OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8.0)),borderSide:
                                 BorderSide(color:Colors.black38)),
                               ),
                               //cursorColor:color.colorConvert(color.PRIMARY_COLOR),
                             ),
                           ),
                           SizedBox(height:18,),
                           GestureDetector(
                             onTap:(){
                               showModalBottomSheet(
                                   context: context,
                                   builder: (BuildContext bc) {
                                     return SafeArea(
                                       child: Container(
                                         child: new Wrap(
                                           children: <Widget>[
                                             new ListTile(
                                                 leading: new Icon(Icons.photo_library),
                                                 title: new Text('Document from Library'),
                                                 onTap: () {
                                                   getDocFromLib();
                                                   Navigator.of(context).pop();
                                                 }),
                                             new ListTile(
                                               leading: new Icon(Icons.photo_camera),
                                               title: new Text('Camera'),
                                               onTap: () {
                                                 getImageFromCamera();
                                                 Navigator.of(context).pop();
                                               },
                                             ),
                                           ],
                                         ),
                                       ),
                                     );
                                   }
                               );
                               },
                             child:Container(
                                 width:Get.size.width-50,
                                 height:56,
                                 decoration:BoxDecoration(
                                     borderRadius:BorderRadius.circular(10.0),
                                     border:Border.all(width:2,color:color.colorConvert(colorCode))
                                 ),
                                 child:Center(
                                     child:
                                     Row(
                                       mainAxisAlignment:MainAxisAlignment.spaceAround,
                                       children: [
                                         SizedBox(width:10,),
                                         Expanded(
                                           flex:10,
                                           child:Text(fileStr==null?"Attach File":fileStr,style:
                                           GoogleFonts.openSans(textStyle:TextStyle(fontSize:15,color:color.colorConvert(colorCode),
                                               fontWeight:FontWeight.w700,letterSpacing:0.0))),
                                         ),
                                         Expanded(
                                           flex:2,
                                           child:Icon(Icons.attach_file,color:color.colorConvert(colorCode),),
                                         )
                                       ],
                                     )
                                 )
                             ),
                           ),

                           Container(
                             margin:EdgeInsets.only(top:2),
                             width:Get.size.width/1.1,
                             child:Row(
                               mainAxisAlignment:MainAxisAlignment.end,
                               children: [
                                 Expanded(
                                     flex:3,
                                     child:Container()),
                                 Expanded(
                                   flex:2,
                                   child:Text(AppStrings.maxSize,
                                       maxLines:2,
                                       overflow: TextOverflow.ellipsis,
                                       softWrap: false,
                                       style: GoogleFonts.openSans(
                                           textStyle: TextStyle(
                                               fontSize:10,
                                               color:Colors.black45,
                                               fontWeight: FontWeight.w700,
                                               letterSpacing: 0.0))),
                                 )
                               ],
                             ),
                           ),

                         ],
                       )

                     ],
                   )),
               SizedBox(height:15,),
               Expanded(
                   flex:2,
                   child:
                   ButtonTheme(
                     minWidth: MediaQuery.of(context).size.width / 2.4,
                     height:55,
                     child: RaisedButton(
                         child: Text(
                           AppStrings.submit,
                           style:
                           TextStyle(fontSize: 16, color: Colors.white),
                         ),
                         color: color.colorConvert(colorCode),
                         shape: RoundedRectangleBorder(
                             borderRadius: BorderRadius.circular(12.0)),
                         onPressed: () {
                           if (projectNameCtrl.value.text.length>0 && briefCtrl.value.text.length>0 && selectedValue!=null) {
                             postRequirment();
                             setState(() {
                               showLoader=true;
                             });
                           }
                           else{
                             ToastMessages.showToast(message:'All fields compulsory',type:false);

                           }
                           // displayPopupDialog(context);
                         }),
                   )
               )

             ],
           )
       ):displayLoader()

   ):displayLoader()
    );
  }

  void getLocations() {
    ApiHandler.requestApi(ApiProvider.baseUrl, EndApi.cities)
        .then((value) {
      Map<String, dynamic> mapData;
      List<dynamic> listRes;
      setState(() {
        mapData = value;
        listRes = mapData[ApiKeys.citiesList];
        print("DATA ${mapData.toString()}");
        print("DATA ${listRes.toString()}");
        _cityDropdownValues.clear();
        _cityDropdownValues=CitiesModel.fromJson(mapData).citiesList;
        /*for (int i = 0; i < listRes.length; i++) {
          _cityDropdownValues.add(listRes[i][ApiKeys.cityName]);
        }*/
        print("DATA cityID ${_cityDropdownValues.toString()}");
      });
    });
  }

  void displayPopupDialog(BuildContext context) {

    showDialog(
        context:context,
    builder:(BuildContext context){
    return Dialog(
    shape:RoundedRectangleBorder(
    borderRadius:BorderRadius.circular(20.0),),
      child:Container(
        decoration:BoxDecoration(
            color:Colors.white,
            borderRadius:BorderRadius.circular(16.0)
        ),
        height:Get.size.height/2.2,
        width:Get.size.width/1.1,
        child:Column(
          children: [
            Row(
              mainAxisSize:MainAxisSize.max,
              children: [
                Expanded(
                    flex:4,
                    child:Container()),
                Expanded(
                    flex:1,
                    child:Container(
                      margin:EdgeInsets.only(top:14),
                      child:GestureDetector(
                        onTap:(){
                          Get.to(OrderPage());
                        },
                        child:SvgPicture.asset('assets/images/Icon_close.svg',height:23,width:23,color:Colors.black54,),
                      )
                    ))
              ],
            ),
            Row(
              mainAxisAlignment:MainAxisAlignment.center,
              children: [
                Container(
                  height:Get.size.height/2.8,
                  width:Get.size.width/1.3,
                  child:Column(
                    children: [
                      Expanded(
                        flex:4,
                        child:Image.asset('assets/images/thank you for request graphic.png',scale:0.9,),),
                      Expanded(
                          flex:2,
                          child:Column(
                            children: [
                              Text(AppStrings.thankForReq,
                                  style: GoogleFonts.openSans(
                                      textStyle: TextStyle(
                                          fontSize: 15,
                                          color:color.colorConvert('#343048').withOpacity(0.6),
                                          fontWeight: FontWeight.w600,
                                          letterSpacing: 0.0))),
                              Text(AppStrings.contactSoon,
                                  style: GoogleFonts.openSans(
                                      textStyle: TextStyle(
                                          fontSize: 15,
                                          color:color.colorConvert('#343048').withOpacity(0.6),
                                          fontWeight: FontWeight.w600,
                                          letterSpacing: 0.0))),
                            ],
                          )),
                      Expanded(
                          flex:1,
                          child:Text(AppStrings.serialNoIs+" "+srNo,
                              style: GoogleFonts.openSans(
                                  textStyle: TextStyle(
                                      fontSize: 15,
                                      color: Colors.black87,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 0.0))))
                    ],
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
    }
    );
  }

  void postRequirment() {
    Box<String> appDb;
    appDb = Hive.box(ApiKeys.appDb);
    String userId=appDb.get(ApiKeys.userId);
    var map={
      'user_id':userId,
      'project_name':selectedValue,
      'project_type':projectNameCtrl.value.text,
      'project_location':selectedLoc,
      'city':selectedCity,
      'brief_description':briefCtrl.value.text,
      'file':uploadedFileUrl,
      'category_name':categoryName,
      'fcm_token':fcmToken

    };
    print("CAT ${map.toString()}");
    ApiHandler.postApi(ApiProvider.baseUrl,EndApi.requirementsPost, map).then((value){
      if (value['user_id']!=null) {
        setState(() {
          srNo=value['sr_no'];
          showLoader=false;
        });
        showLoader=false;
        displayPopupDialog(context);
      }
    });
  }

  displayLoader() {
    return Column(
      mainAxisAlignment:MainAxisAlignment.center,
      children: [
        Container(
          child:Center(
            child:CircularProgressIndicator(),
          ),
        )
      ],
    );
  }

  void getToken()async
  {
    await _firebaseMessaging.getToken().then((value)async{
      setState(() {
        fcmToken=value;
      });
    });
    print("fcmToken ${fcmToken}");
  }

  void initNotification() async{

    _firebaseMessaging.configure(
        onMessage:(Map<String,dynamic>map)async{
          print("Notification ${map['notification']}");
          Map<String,dynamic>mapData;
          setState(() {
            mapData={"title":map['notification']['title'],
              "body":map['notification']['body']};
          });
          print("Notification ${map['notification'].toString()}");
          print("Notification ${map['notification']['title']}");
          print("Notification ${map['notification']['body']}");

          print("Notification ${mapData.toString()}");
          _showNotification(mapData);

        },
        onLaunch:(Map<String,dynamic>map)async{
          print("Notification l${map.toString()}");
          //_showNotification(map);

        },
        //onBackgroundMessage:myBackgroundHandler,
        onResume:(Map<String,dynamic>map)async{
          print("Notification r ${map.toString()}");
        }
    );
  }
  Future _showNotification(Map<String, dynamic> mesage) async {
    var androidPlatformChannelSpecifics = AndroidNotificationDetails(
        'channel_ID', 'channel_name', 'channel description',
        importance: Importance.high,
        playSound: true,
        // sound: 'sound',
        showProgress: true,
        priority: Priority.high,
        ticker: 'test ticker');

    var platformChannelSpecifics =
    NotificationDetails(android: androidPlatformChannelSpecifics);
    print("Channel :${platformChannelSpecifics.android.channelId}");
    await flutterLocalNotificationsPlugin.show(0, mesage['title'],
        mesage['body'], platformChannelSpecifics,
        payload: 'Default_Sound');
  }

  void _showPicker(BuildContext context)async {

    Future<void> _showPicker(BuildContext context) async{
      await
      showModalBottomSheet(
          context: context,
          builder: (BuildContext bc) {
            return SafeArea(
              child: Container(
                child: new Wrap(
                  children: <Widget>[
                    new ListTile(
                        leading: new Icon(Icons.photo_library),
                        title: new Text('Document from Library'),
                        onTap: () {
                          getDocFromLib();
                          Navigator.of(context).pop();
                        }),
                    new ListTile(
                      leading: new Icon(Icons.photo_camera),
                      title: new Text('Camera'),
                      onTap: () {
                        getImageFromCamera();
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            );
          }
      );
    }

  }

  void getDocFromLib() async{
    FilePickerResult result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'pdf', 'docx'],
    );
    print("result ${result.paths[0]}");
    setState(() {
      image=File(result.paths[0]);
      String fileName = image.path.split('/').last;
      var dir=image.parent.path;
      fileStr=fileName;
      print("image ${image}");
      print("fileName ${fileName}");
      print("dir ${dir}");
     // uploadImage(ApiProvider.baseUrlUpload,image);
      uploader(fileName:fileName,directory:dir,image:image);
    });
  }
  Future getImageFromCamera() async{
    final pickedFile=await picker.getImage(source: ImageSource.camera);
    setState(() {
      if(pickedFile!=null){
        image = File(pickedFile.path);
        String fileName = image.path.split('/').last;
        var dir=image.parent.path;
        print("image ${image}");
        print("fileName ${fileName}");
        print("dir ${dir}");

        uploader(fileName:fileName,directory:dir);
        setState(() {
          croppedImage=image;
          showLoader=true;
        });
      }
    });
  }

  static Future<Map<String,dynamic>>uploader({fileName,directory,File image})async{
    var request = http.MultipartRequest('POST', Uri.parse(ApiProvider.baseUrlUpload));


     dynamic prog;
    Map<String,dynamic>map;
    final uploader = FlutterUploader();
    String fileName = await image.path.split('/').last;

    print("FILENAME ${fileName} FILENAME ${directory}");

    final taskId=await uploader.enqueue(url:ApiProvider.baseUrlUpload,
        files:[FileItem(filename:fileName,
            savedDir:directory)],
        method:UploadMethod.POST,
        headers: {"apikey": "api_123456", "userkey": "userkey_123456"},
        showNotification:true
    );
    final subscription = uploader.progress.listen((progress) {

    });

    final subscription1 =uploader.result.listen((result) {
//    print("Progress result ${result.response}");

      // return result.response;
    }, onError: (ex, stacktrace) {
    });
    subscription1.onData((data)async {

        map=await json.decode(data.response);
      print("PATH data ${map['url']}");
      uploadedFileUrl=map['url'].toString();
    });
    return map;
  }
  uploadImage(String url, File croppedImage) async {
    var postUri = Uri.parse(url);
    print('URI ${url}${croppedImage}');
    Map<String, dynamic>map;
    http.MultipartRequest request = await new http.MultipartRequest(
        "POST", postUri);


    http.MultipartFile multipartFile = await http.MultipartFile.fromPath(
        'file', croppedImage.path);

    request.files.add(multipartFile);

    http.StreamedResponse response = await request.send();
    String imgUrl;
    response.stream.transform(utf8.decoder).listen((event) {
      print("IMG_RESPONSE ${event}");
      setState(() {
        map = json.decode(event);
        print("IMG_RESPONSE ${map.toString()}");

      });
      Get.back();

      setState(() {
      });
    });
  }

  void getLocality() {

setState(() {
  _localityDropdownValues.clear();
  selectedLoc=null;
});
    if (selectedCityId != null && selectedCityId != '') {
      var map = {'city_id':selectedCityId};
      ApiHandler.postApi(ApiProvider.baseUrl, EndApi.locality, map)
          .then((value) {
        Map<String, dynamic> mapData;
        List<dynamic> listRes;
        setState(() {
          mapData = value;
          listRes = mapData[ApiKeys.localatyList];
          print("DATA  locality${mapData.toString()}");
          print("DATA ${listRes.toString()}");
        });
        for (int i = 0; i < listRes.length; i++) {
          _localityDropdownValues.add(listRes[i][ApiKeys.areaName]);
          //subCatIdList.add(listRes[i][ApiKeys.subCategoryId]);
        }

      });
    }
  }

}