import 'package:equatable/equatable.dart';

abstract class SubCatEvent extends Equatable
{

}
class FetchSubCatEvent extends SubCatEvent
{
  @override
  // TODO: implement props
  List<Object> get props => throw UnimplementedError();

}