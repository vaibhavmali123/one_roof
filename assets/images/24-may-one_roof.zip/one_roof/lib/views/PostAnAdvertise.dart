import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:one_roof/utils/AppStrings.dart';
import 'package:one_roof/utils/color.dart';

class PostAnAdvertise extends StatefulWidget
{

  PostAnAdvertiseState createState()=>PostAnAdvertiseState();
}

class PostAnAdvertiseState extends State<PostAnAdvertise>
{
  @override
  Widget build(BuildContext context) {
  return Scaffold(
    body:SafeArea(
        child:Container(
          width:Get.size.width,
          child:
          Column(
            crossAxisAlignment:CrossAxisAlignment.center,
            children: [
              Expanded(
                  flex:4,
                  child:Column(
                    children: [
                      Image.asset('assets/images/Empty state.png',scale:0.8,),
                      SizedBox(height:14,),
                      Text('Hello ',
                          style: GoogleFonts.openSans(
                              textStyle: TextStyle(
                                  fontSize:15,
                                  color: Colors.black87,
                                  fontWeight:FontWeight.w700,
                                  letterSpacing: 0.0))),
                    ],
                  )),
              Expanded(
                flex:6,
                child:Column(
                  children: [

                    Text(AppStrings.relaxStr,
                        style: GoogleFonts.openSans(
                            textStyle: TextStyle(
                                fontSize: 12,
                                color:color.colorConvert('#6B6977'),
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.0))),
                    Text(AppStrings.getBackStr,
                        style: GoogleFonts.openSans(
                            textStyle: TextStyle(
                                fontSize: 13,
                                color:color.colorConvert('#6B6977'),
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.0))),
                    SizedBox(height:30,),

                    Text('OR',
                        style: GoogleFonts.openSans(
                            textStyle: TextStyle(
                                fontSize: 15,
                                color: Colors.black87,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.0))),
                    SizedBox(height:30,),

                    Text(AppStrings.postingAdd,
                        style: GoogleFonts.openSans(
                            textStyle: TextStyle(
                                fontSize: 12,
                                color:color.colorConvert('#6B6977'),
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.0))),
                    Text(AppStrings.meanwhile,
                        style: GoogleFonts.openSans(
                            textStyle: TextStyle(
                                fontSize: 13,
                                color:color.colorConvert('#6B6977'),
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.0))),
                    SizedBox(height:24,),

                    ButtonTheme(
                      minWidth:MediaQuery.of(context).size.width/2.4,
                      height:52,
                      child:RaisedButton(
                          child:Text(AppStrings.createAd,style:TextStyle(fontSize:16,color:Colors.white),),
                          color:color.colorConvert(color.primaryColor),
                          shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12.0)),
                          onPressed:(){

                          }),),
                  ],
                ),
              )
            ],
          ),
        )
    ),
  ) ;
  }
}