class Multiselection<T>
{
  bool isSelected=false;

T data;

  Multiselection(this.data);
}