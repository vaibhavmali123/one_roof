import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:one_roof/firebase/NotificationService.dart';
import 'package:one_roof/networking/ApiHandler.dart';
import 'package:one_roof/networking/ApiKeys.dart';
import 'package:one_roof/networking/ApiProvider.dart';
import 'package:one_roof/networking/EndApi.dart';
import 'package:one_roof/utils/Constants.dart';
import 'package:one_roof/utils/color.dart';
import 'package:url_launcher/url_launcher.dart';

class ContractorDetails extends StatefulWidget {
  String workerId,srNo,name,email,mno;

  ContractorDetails({this.workerId,this.srNo,this.name,this.email,this.mno});

  ContractorDetailsState createState() => ContractorDetailsState(workerId:workerId,srNo:srNo,name:name,email:email,mno:mno);
}

class ContractorDetailsState extends State<ContractorDetails> {
  List<String> listMachine = ['JCB', 'BOB cat', 'Dumper', 'Crane'];
  List<dynamic>listMac=[];
  List<dynamic>list=[];
  String workerId,srNo,name,email,mno,userType;
  double rating=1;
  ContractorDetailsState({this.workerId,this.srNo,this.name,this.email,this.mno});

  bool showLoader=true;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    NotificationService.configureNotification();

    getUserDetails();
    userType==Constants.hire?getWorkerDetails():getUserDetails();
    print("NAME ${name} ${srNo} ${email} ${mno}");

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(75),
          child: Column(
            children: [
              SizedBox(
                height: 15,
              ),
              AppBar(
                backgroundColor: Colors.white,
                elevation: 2,
                automaticallyImplyLeading: false,
                centerTitle: true,
                actions: [
                  Container(
                    width: Get.size.width,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 14,
                        ),
                        Expanded(
                          flex: 8,
                          child: Text('Worker',
                              style: TextStyle(
                                  fontSize: 17,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w700)),
                        ),
                        Expanded(
                          flex: 1,
                          child: Container(),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                      ],
                    ),
                  ),
                ],
              )
            ],
          )),
      body:
      Stack(
        children: [
          showLoader==false?
          SingleChildScrollView(
            child:Container(

              height:Get.size.height,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 20),
                        height:190,
                        width: Get.size.width / 1.1,
                        decoration: BoxDecoration(
                            color: color.colorConvert('EBF2FA').withOpacity(1),
                            borderRadius: BorderRadius.circular(14.0)),
                        child: Padding(
                          padding: EdgeInsets.only(left:0,top:12,bottom:12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Expanded(
                                      flex: 2,
                                      child: Image.asset(
                                        'assets/images/profile pic.png',
                                        scale: 1,
                                      )),
                                  Expanded(
                                      flex: 4,
                                      child: Container(
                                        child: Column(
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              children: [
                                                Text(
                                                   userType==Constants.hire?list[0]['first_name']!=null?
                                              list[0]['first_name']+" "+list[0]['last_name']:"":name,
                                                    overflow: TextOverflow.ellipsis,
                                                    softWrap: false,
                                                    style: GoogleFonts.openSans(
                                                        textStyle: TextStyle(
                                                            fontSize: 14,
                                                            color: color.colorConvert(
                                                                '#343048'),
                                                            fontWeight:
                                                            FontWeight.w700,
                                                            letterSpacing: 0.0)))
                                                /*Text(userType==Constants.hire?list[0]['first_name']!=null?
                                              list[0]['first_name']+" "+list[0]['last_name']:"":name,
                                                  overflow: TextOverflow.ellipsis,
                                                  softWrap: false,
                                                  style: GoogleFonts.openSans(
                                                      textStyle: TextStyle(
                                                          fontSize: 14,
                                                          color: color.colorConvert(
                                                              '#343048'),
                                                          fontWeight:
                                                          FontWeight.w700,
                                                          letterSpacing: 0.0)))*/,
                                              ],
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              children: [
                                                Text(userType==Constants.hire?
                                                list[0]['mobile_number']!=null?list[0]['mobile_number']:"":mno,
                                                    overflow: TextOverflow.ellipsis,
                                                    softWrap: false,
                                                    style: GoogleFonts.openSans(
                                                        textStyle: TextStyle(
                                                            fontSize: 13,
                                                            color: color.colorConvert(
                                                                '#6B6977'),
                                                            fontWeight:
                                                            FontWeight.w600,
                                                            letterSpacing: 0.0))),
                                              ],
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              children: [
                                                Text(userType==Constants.hire?
                                                list[0]['email']!=null?list[0]['email']:"":email,
                                                    overflow: TextOverflow.ellipsis,
                                                    softWrap: false,
                                                    style: GoogleFonts.openSans(
                                                        textStyle: TextStyle(
                                                            fontSize: 13,
                                                            color: color.colorConvert(
                                                                '#6B6977'),
                                                            fontWeight:
                                                            FontWeight.w600,
                                                            letterSpacing: 0.0))),
                                              ],
                                            ),
                                          ],
                                        ),
                                      )),
                                  Expanded(
                                      flex: 2,
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Container(
                                            color: Colors.white,
                                            height:25,
                                            width: 200,
                                            child:Row(
                                              children: [
                                                Icon(rating==1 || rating>=1? Icons.star:Icons.star_border
                                                  ,color:rating==1 || rating>=1?Colors.orangeAccent:Colors.black45,size:18,),

                                                Icon(rating==2 || rating>=2? Icons.star:Icons.star_border
                                                  ,color:rating==2 || rating>=2?Colors.orangeAccent:Colors.black45,size:18,),

                                                Icon(rating==3 || rating>=3? Icons.star:Icons.star_border,
                                                  color:rating==3 || rating>=3?Colors.orangeAccent:Colors.black45,size:18,),

                                                Icon(rating==4 || rating>=4? Icons.star:Icons.star_border
                                                  ,color:rating==4 || rating>=4?Colors.orangeAccent:Colors.black45,size:18,),

                                                Icon(rating==5 || rating>=5? Icons.star:Icons.star_border,
                                                  size:18,color:rating==5 || rating>=5?Colors.orangeAccent:Colors.black45,)
                                              ],
                                            ),
                                          ),
                                          Container(
                                            height: 25,
                                          )
                                        ],
                                      ))
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    width: 18,
                                  ),
                                  userType==Constants.hire?Container(
                                    width: Get.size.width / 1.4,
                                    child:
                                    Text(
                                        'Experience He is been working from past 3 years in this industry!',
                                        overflow: TextOverflow.ellipsis,
                                        softWrap: false,
                                        maxLines: 2,
                                        style: GoogleFonts.openSans(
                                            textStyle: TextStyle(
                                                fontSize: 12,
                                                color: color.colorConvert('#6B6977'),
                                                fontWeight: FontWeight.w600,
                                                letterSpacing: 0.0))),
                                  ):Container(),
                                ],
                              ),
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  userType==Constants.hire?Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.only(left: 30),
                        width: Get.size.width / 1.1,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('List of Machinaries',
                                style: GoogleFonts.openSans(
                                    textStyle: TextStyle(
                                        fontSize: 15,
                                        color: color
                                            .colorConvert('#0D082B')
                                            .withOpacity(0.8),
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 0.0))),
                            Container(
                              margin: EdgeInsets.only(top: 10),
                              height: 140,
                              child: ListView.builder(
                                itemCount: listMac.length,
                                itemBuilder: (context, index) {
                                  return Padding(
                                    padding: EdgeInsets.only(top: 15),
                                    child: Row(
                                      children: [
                                        Expanded(
                                            flex: 8, child: Text(listMac[index]['name'].toString())),
                                        Expanded(
                                          flex: 1,
                                          child: Text(listMac[index]['count'].toString()),
                                        )
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ):Container(),
                  SizedBox(
                    height: 18,
                  ),
                  userType==Constants.hire?Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.only(left: 30),
                        width: Get.size.width / 1.1,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Team strength',
                                style: GoogleFonts.openSans(
                                    textStyle: TextStyle(
                                        fontSize: 15,
                                        color: color
                                            .colorConvert('#0D082B')
                                            .withOpacity(0.8),
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 0.0))),
                            userType==Constants.hire?Container(
                                margin: EdgeInsets.only(top: 10),
                                height: 100,
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(flex: 8, child: Text('Unskilled')),
                                        Expanded(flex: 1, child: Text(list[0]['non_skilled_labour']!=null?list[0]['non_skilled_labour']:"0"))
                                      ],
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        Expanded(flex: 8, child: Text('Skilled')),
                                        Expanded(flex: 1, child: Text(list[0]['skilled_labour']!=null?list[0]['skilled_labour']:"0"))
                                      ],
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        Expanded(flex: 8, child: Text('Technical’s')),
                                        Expanded(flex: 1, child: Text(list[0]['technical_staff']!=null?list[0]['technical_staff']:"0"))
                                      ],
                                    )
                                  ],
                                )):Container(),
                          ],
                        ),
                      ),
                    ],
                  ):Container(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      userType==Constants.hire?Container(
                        margin: EdgeInsets.only(left: 30),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Turnover',
                                style: GoogleFonts.openSans(
                                    textStyle: TextStyle(
                                        fontSize: 15,
                                        color: color
                                            .colorConvert('#0D082B')
                                            .withOpacity(0.8),
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 0.0))),
                            SizedBox(
                              height: 18,
                            ),
                            Container(
                              width: Get.size.width / 1.1,
                              child: Row(
                                children: [
                                  Expanded(flex: 6, child: Text('Annual')),
                                  Expanded(
                                    flex: 2,
                                    child: Text(list[0]['turnover']!=null?"₹ "+list[0]['turnover'].toString():"0"),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ):Container()
                    ],
                  ),
                  SizedBox(
                    height: 18,
                  ),
                  userType==Constants.hire?Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 48,
                        width: Get.size.width / 3,
                        child: RaisedButton(
                            child: Text(
                              'Contact',
                              style: TextStyle(fontSize: 16, color: Colors.white),
                            ),
                            color: color.colorConvert(color.primaryColor),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.0)),
                            onPressed: () {
                              updateStatus();
                              launch("tel:"+list[0]['mobile_number']);

                              // Get.to(ContractorDetails());
                            }),
                      )
                    ],
                  ):Container()
                ],
              ),
            ),
          ):displayLoader()
        ],
      ),
    );
  }

  void getWorkerDetails() {
    Box<String> appDb;

    appDb = Hive.box(ApiKeys.appDb);
    String userId = appDb.get(ApiKeys.userId);
    print("RESP ${userId}");

    var map = {'user_id':workerId};
    ApiHandler.postApi(ApiProvider.baseUrl, EndApi.workerDetails, map)
        .then((value) {
          Map<String,dynamic>map;
          print("RESP ${value}");

          setState(() {
            showLoader=false;
            map=value;
            list=map['result'];
            showLoader=false;
            listMac=json.decode(list[0]['equipments']);
          });
          print("list ${listMac}");

          if (map['statusCode']=='200' || map['statusCode']=='201') {
          setState(() {
            list=map['result'];
          });
          }
      print("RESP ${value}");
          print("rating ${list[0]['rating'].runtimeType}");
          setState(() {
            rating=int.parse(list[0]['rating'])/5;
          });
          print("RESP listMac ${rating.round()}");

    });
  }

  displayLoader() {
    return Center(
      child:CircularProgressIndicator(),
    );
  }

  void getUserDetails() {
    Box<String> appDb;
    appDb = Hive.box(ApiKeys.appDb);

    setState(() {
      userType=appDb.get(ApiKeys.type);
      showLoader=false;
      print("NAME userType ${userType}");

    });

  }

  void updateStatus() {
    print("SST ${srNo.toString()} ${workerId.toString()}");

    var map={
      "sr_no":srNo,
      'worker_id':workerId
    };

    print("SST ${map.toString()}");
    ApiHandler.postApi(ApiProvider.baseUrl,EndApi.contactStatus,map).then((value){
      if (value['statusCode=200']) {
        print("SST ${value.toString()}");
      }
    });
  }
}
