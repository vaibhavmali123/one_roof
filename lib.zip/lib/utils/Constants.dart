class Constants {
  static String hireFlag = 'hireFlag';
  static String workFlag = 'WorkFlag';
  static String countList = 'countList';
  static String logedInFlag = 'logedInFlag';
  static String hire = 'hire';
  static String work = 'work';
  static String projectType = 'projectType';
  static String city = 'city';
  static String location = 'location';
  static String file = 'file';
  static String none = 'none';
  static String addMore = 'addMore';
  static String requiredWithin = 'requiredWithin';
//Machinery & Equipment
  static String machineryAndEquipment = 'Machinery Hiring';
  static String constructionMaterial = 'Construction Material';
  static String hrManagement = 'HR Management';
  static String projectMAnagement = 'Project Management';
  static String contractors = 'Contractors';
}
