import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:one_roof/networking/ApiHandler.dart';
import 'package:one_roof/networking/ApiKeys.dart';
import 'package:one_roof/networking/ApiProvider.dart';
import 'package:one_roof/networking/EndApi.dart';
import 'package:one_roof/utils/color.dart';
import 'package:one_roof/models/PaymentModel.dart';
import 'package:path_provider/path_provider.dart';
class PaymentScreen extends StatefulWidget{

  PaymentScreenState createState()=>PaymentScreenState();
}

class PaymentScreenState extends State<PaymentScreen>
{
  var isChecked=false;
List<Result>list=[];
List<bool>isCheckedList=[];
int total=0;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserPayment();
  }

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(75),
          child: Column(
            children: [
              SizedBox(
                height: 15,
              ),
              AppBar(
                backgroundColor: Colors.white,
                elevation: 2,
                leading:GestureDetector(
                  onTap:(){
                    Get.back();
                  },
                  child: Image.asset(
                    'assets/images/back_icon.png',
                    scale: 1.8,
                  ),
                ),
                automaticallyImplyLeading: false,
                centerTitle: true,
                title:Text('Payment',
                    style: TextStyle(
                        fontSize: 17,
                        color: Colors.black,
                        fontWeight: FontWeight.w700)),
              )
            ],
          )),
      bottomNavigationBar:
      bottomNav(),
      body:Container(
        width:Get.size.width,
        child:
        Column(
          crossAxisAlignment:CrossAxisAlignment.center,
          children: [
            SizedBox(height:10,),
            Text(
                "Due Payments",
                softWrap: false,
                style: GoogleFonts.openSans(
                    textStyle: TextStyle(
                        color:color.colorConvert('#343048'),
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.0))),
            SizedBox(height:24,),
            getList(),
          ],
        ),
      ),
    );
  }

  void getUserPayment() {
    Box<String> appDb;
    appDb = Hive.box(ApiKeys.appDb);
    String userId=appDb.get(ApiKeys.userId);

    var map={
      'user_id':userId
    };
    ApiHandler.postApi(ApiProvider.baseUrl,EndApi.paymentInfo, map).then((value){
      print("value ${value}");
      if (value['Status_code']=="200" || value['Status_code']=="201") {

        print("value ${value}");
        setState(() {
          list=PaymentModel.fromJson(value).result.toList();
        });
        for(int i=0;i<list.length;i++)
          {
            isCheckedList.add(false);
          }
      }
    });
  }

  bottomNav() {
    return Container(
      color:Colors.white,
      height:70,
      padding:EdgeInsets.only(left:15,right:15),
      child:
      Row(
        mainAxisAlignment:MainAxisAlignment.spaceBetween,
        children: [
          Column(
            mainAxisAlignment:MainAxisAlignment.spaceEvenly,
            crossAxisAlignment:CrossAxisAlignment.start,
            children: [
              Text(
                  "Total",
                  softWrap: false,
                  style: GoogleFonts.openSans(
                      textStyle: TextStyle(
                          fontSize: 14,
                          color:color.colorConvert(color.primaryColor),
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.0))),
              Text(
                  "₹ "+total.toString()+"/-",
                  softWrap: false,
                  style: GoogleFonts.openSans(
                      textStyle: TextStyle(
                          fontSize: 14,
                          color:color.colorConvert(color.primaryColor),
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.0))),

            ],
          ),
          SizedBox(
            width:120,
            height:45,
            child:RaisedButton(
              shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(10.0),),
              color:color.colorConvert(color.primaryColor),
              onPressed:(){},
              child:Text(
                  "Pay",
                  softWrap: false,
                  style: GoogleFonts.openSans(
                      textStyle: TextStyle(
                          fontSize: 14,
                          color:Colors.white,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.0))),
            ),
          )
        ],
      ),
    );
  }

  getList() {
    return Expanded(child:
    ListView.builder(
      itemCount:list.length,
      itemBuilder:(context,index){
        return Container(
          height:70,
          margin:EdgeInsets.only(top:18),
          child:Row(
            crossAxisAlignment:CrossAxisAlignment.start,
            mainAxisAlignment:MainAxisAlignment.spaceEvenly,
            children: [
              SizedBox(
                child:Container(
                  height:30,
                  child:Checkbox(value:isCheckedList[index],
                      onChanged:(value){
                        setState(() {
                          if (isCheckedList[index]==true) {
                            isCheckedList[index]=false;
                            total=total-int.parse(list[index].amount);

                          }
                          else{
                            isCheckedList[index]=true;
                            total=int.parse(list[index].amount)+total;
                          }
                        });
                      }),
                ),
              ),
              Column(
                crossAxisAlignment:CrossAxisAlignment.start,
                children: [
                  Text(
                      list[index].srNo,
                      softWrap: false,
                      style: GoogleFonts.openSans(
                          textStyle: TextStyle(
                              fontSize:15,
                              color:color.colorConvert('#343048'),
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.0))),
                  SizedBox(height:5,),
                  Text(
                      list[index].amount!=null?"₹ "+list[index].amount:" ",
                      softWrap: false,
                      style: GoogleFonts.openSans(
                          textStyle: TextStyle(
                              color:Colors.black54,
                              fontSize:13,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.0))),
                ],
              ),
              GestureDetector(
                onTap:(){
                  print("FILE }");

                  var httpClient = new HttpClient();
                   Future<File> _downloadFile(String url, String filename) async {
                     var request = await httpClient.getUrl(Uri.parse('https://sncfinancialconsulting.in/one_roof/uploads/images/60a8b525cbb17.pdf'));
                     var response = await request.close();
                     print("FILE ${response.statusCode}");
                     print("FILE ${response.toList().toString()}");

                     var bytes = await consolidateHttpClientResponseBytes(response);
                     String dir = (await getApplicationDocumentsDirectory()).path;
                     File file = new File('$dir/$filename');
                     await file.writeAsBytes(bytes);
                     print("FILE ${file.path.toString()}");
                     return file;
                   }


                },
                child:Container(
                  height:45,
                  width:150,
                  decoration:BoxDecoration(
                      borderRadius:BorderRadius.circular(10.0),
                      border:Border.all(width:1,color:color.colorConvert(color.primaryColor))
                  ),
                  child:Center(
                    child:Text(
                        "Download Invoice",
                        softWrap: false,
                        style: GoogleFonts.openSans(
                            textStyle: TextStyle(
                                color:color.colorConvert(color.primaryColor),
                                fontWeight: FontWeight.w500,
                                letterSpacing: 0.0))),
                  ),
                ),
              )
            ],
          ),
        );
      },
    ));
  }
}