class Constants
{
  static String hireFlag='hireFlag';
  static String workFlag='WorkFlag';
  static String countList='countList';
  static String logedInFlag='logedInFlag';
  static String hire='hire';
  static String work='work';
}