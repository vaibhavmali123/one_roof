import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:one_roof/firebase/NotificationService.dart';
import 'package:one_roof/one__roof_icons.dart';
import 'package:one_roof/utils/AppStrings.dart';
import 'package:one_roof/networking/ApiHandler.dart';
import 'package:one_roof/networking/ApiKeys.dart';
import 'package:one_roof/networking/ApiProvider.dart';
import 'package:one_roof/networking/EndApi.dart';
import 'package:one_roof/utils/ToastMessages.dart';
import 'package:one_roof/utils/color.dart';
import 'package:one_roof/views/PostRequirement.dart';

class SpecialisationPage extends StatefulWidget
{
  String specialisation,id,categoryName;

  String color;
  SpecialisationPage(this.id,this.specialisation,this.color,this.categoryName);

  SpecialisationPageState createState()=>SpecialisationPageState(id,specialisation,color,categoryName);
}

class SpecialisationPageState extends State<SpecialisationPage>
{
  String specialisation,id,categoryName;
   List<dynamic> _specializationList = [];
  var groupValue,selectedValue;
  int indexSelected;
  bool showLoader=true;
  String colorCode;

  SpecialisationPageState(this.id,this.specialisation,this.colorCode,this.categoryName);

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    NotificationService.configureNotification();

    getSpecialisations();
   print("DATA ${id}");
  }

  @override
  Widget build(BuildContext context)
  {
  return Scaffold(
    appBar: PreferredSize(
        preferredSize: Size.fromHeight(75),
        child: Column(
          children: [
            SizedBox(
              height: 15,
            ),
            AppBar(
              backgroundColor: Colors.white,
              elevation:2,
              centerTitle: true,
              automaticallyImplyLeading:false,
              actions: [
                Container(
                  width:Get.size.width,
                  child:Row(
                    mainAxisAlignment:MainAxisAlignment.start,
                    children: [
                      Expanded(
                          flex:1,
                          child:GestureDetector(
                            onTap:(){
                              Get.back();
                            },
                            child: Image.asset(
                              'assets/images/back_icon.png',
                              scale: 1.8,
                            ),
                          )),
                      Expanded(
                        flex:5,
                        child:Text(specialisation,
                            style: TextStyle(
                                fontSize: 17,
                                color: Colors.black,
                                fontWeight: FontWeight.w700)),),
                      Expanded(
                        flex:1,
                        child:Container(),
                      )
                    ],
                  ),
                )
              ],
            )
          ],
        )),
    body:
    showLoader!=true?Container(
      child:Column(
        children: [
          SizedBox(height:16,),
          Expanded(
              flex:1,
              child:getTopTextLine()),
          Expanded(
              flex:16,
              child:getList()),
          Align(
            alignment:Alignment.bottomCenter,
            child:
            Padding(
              padding:EdgeInsets.only(bottom:20),
              child:ButtonTheme(
                minWidth: MediaQuery.of(context).size.width / 2.4,
                height: 52,
                child: RaisedButton(
                    child: Text(
                      AppStrings.select,
                      style:
                      TextStyle(fontSize: 16, color: Colors.white),
                    ),
                    color: color.colorConvert(colorCode),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12.0)),
                    onPressed: () {
                      print("DATA ${selectedValue}");
                      if (selectedValue!=null) {
                        Get.to(PostRequirement(selectedValue,colorCode,categoryName));
                      }
                      else{
                        ToastMessages.showToast(message:AppStrings.selectSpec,type:false);
                      }
                    }),
              ),
            ),
          )
        ],
      ),
    ):displayLoader()
  );
  }

  void getSpecialisations() {
    var map = {'subcategory_id':id};


    ApiHandler.postApi(ApiProvider.baseUrl, EndApi.specialization, map)
        .then((value) {
      Map<String, dynamic> mapData;
      List<dynamic> listRes;
      setState(() {
        mapData = value;
        _specializationList = mapData[ApiKeys.specialisationList];
        print("DATA ${mapData.toString()}");
        showLoader=false;
      });
    });

  }

  getTopTextLine() {
    return Row(
      mainAxisAlignment:MainAxisAlignment.center,
      children: [
        Text(AppStrings.selectConsultant,
            maxLines:2,
            overflow: TextOverflow.ellipsis,
            softWrap: false,
            style: GoogleFonts.openSans(
                textStyle: TextStyle(
                    fontSize:15,
                    color:color.colorConvert('#343048').withOpacity(0.8),
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.0))),
      ],
    );
  }

  getList() {
    return Row(
      mainAxisAlignment:MainAxisAlignment.center,
      children: [Container(
        width:Get.size.width,
        child:ListView.builder(
          itemCount:_specializationList.length,
          itemBuilder:(context,index){
            return Container(
              child:Row(
                mainAxisAlignment:MainAxisAlignment.center,
                children: [
                  Expanded(
                      flex:1,
                      child:Container()),
                  Expanded(
                      flex:1,
                      child:SizedBox(
                        height:50,
                        width:40,
                        child:Radio(
                            activeColor:color.colorConvert(colorCode),
                            value:_specializationList[index][ApiKeys.specialisation],
                            groupValue:groupValue,
                            onChanged:(value){
                              setState(() {
                                indexSelected=index;
                                groupValue=value;
                                selectedValue=value;
                              });
                            }),
                      )),
                  Expanded(
                      flex:4,
                      child:
                      GestureDetector(
                        onTap:(){
                          setState(() {
                            indexSelected=index;
                            groupValue=_specializationList[index][ApiKeys.specialisation];
                            selectedValue=_specializationList[index][ApiKeys.specialisation];
                          });
                        },
                        child:Text(_specializationList[index][ApiKeys.specialisation],
                            maxLines:2,
                            overflow: TextOverflow.ellipsis,
                            softWrap: true,
                            style: GoogleFonts.openSans(
                                textStyle: TextStyle(
                                    fontSize:14,
                                    color:index!=indexSelected?color.colorConvert('#6B6977'):color.colorConvert(colorCode),
                                    fontWeight: FontWeight.w600,
                                    letterSpacing: 0.0))),
                      )),
                  Expanded(
                      flex:1,
                      child:Container()),
                ],
              ),
            );
          },
        ),
      )],
    );
  }

  displayLoader() {
    return Column(
      mainAxisAlignment:MainAxisAlignment.center,
      children: [
        Center(
          child:CircularProgressIndicator(),
        )
      ],
    );
  }}