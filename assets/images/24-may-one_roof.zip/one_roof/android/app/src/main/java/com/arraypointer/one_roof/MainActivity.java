package com.arraypointer.one_roof;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {

}
