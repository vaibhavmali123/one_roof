import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'dart:async' show Future;
import 'package:flutter/services.dart' show rootBundle;
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:one_roof/models/FaqModel.dart';

class FaqScreen extends StatefulWidget
{

  FaqScreenState createState()=>FaqScreenState();
}

class FaqScreenState extends State<FaqScreen>
{
  List<dynamic>listFaqs=[];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getJson();
  }
  @override
  Widget build(BuildContext context)
  {
  return Scaffold(
    appBar:
    AppBar(
      backgroundColor:Colors.white,
      leading:IconButton(icon:Icon(Icons.keyboard_backspace,color:Colors.black87,), onPressed:(){
        Get.back();
      }),
      title:Text(
        'FAQs',style:TextStyle(fontSize:16,
          color:Colors.black87,fontWeight:FontWeight.w800),),),
    body:Container(
      child:ListView.builder(
          itemCount:listFaqs.length,
          itemBuilder:(context,index){
            return Container(
             margin:EdgeInsets.only(left:18,right:14,top:24),
              child:Column(
                crossAxisAlignment:CrossAxisAlignment.start,
                children: [
                  Text(listFaqs[index]['question'],
                      style:TextStyle(fontSize:18,color:Colors.black87,fontWeight:FontWeight.w800)),
                  Text(listFaqs[index]['answer'],
                      style:TextStyle(fontSize:15,color:Colors.black54,fontWeight:FontWeight.w600,height:1.8))
                ],
              ),
            );
          }),
    ),

  );
  }

  Future<String> getJson() async{
    var jsonText=await rootBundle.loadString('assets/json/FaqJson');
    setState(() {
      var map=json.decode(jsonText);
      listFaqs=map['list'];
//      listFaqs=FaqModel.fromJson(map)
      print("jsonText ${jsonText}");
      print("jsonText ${listFaqs.toString()}");

    });
  }
}