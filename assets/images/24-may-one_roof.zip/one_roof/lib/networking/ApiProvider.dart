class ApiProvider{
  static String baseUrl='http://oneroofcm.com/admin/api/';
  //static String baseUrl='http://sncfinancialconsulting.in/one_roof/api/';
  static String baseUrlUpload='http://sncfinancialconsulting.in/one_roof/index.php/api/FileUpload/uploadFile';
}