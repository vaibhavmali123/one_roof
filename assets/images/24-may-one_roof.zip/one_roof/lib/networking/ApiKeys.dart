class ApiKeys
{
  static String result='result';
  static String statusCode='Status_code';
  static String type='type';
  static String categoryList='Category_list';
  static String categoryName='category_name';
  static String designationName='designation_name';
  static String id='id';
  static String subCatList='subcategory_list';
  static String subcategory='subcategory';
  static String subCategoryId='subcstegory_id';
  static String specialisation='specialisation';
  static String specialisationList='specialisation_list';
  static String userId='userid';
  static String citiesList='Cities_list';
  static String cityName='city_name';
  static String appDb='appDb';
  static String trackScreen;
  static String areaName='area_name';
  static String localatyList='locality_list';
  static String colorCode='color_code';
static String crNo='sr_no';
static String first_name='first_name';
static String last_name='last_name';
static String mobile_number='mobile_number';
static String email='email';
static String address='address';
static String profileUrl='profileUrl';
static String assignedCatList='assignedCatList';
static String fromNotification='fromNotification';
}